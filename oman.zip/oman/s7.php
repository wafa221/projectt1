﻿<html><head>
<style type="text/css">
#header {
background-color:blue;
    
    color:white;
    text-align:center;
    padding:5px;
}
#nav {
    line-height:30px;
   
    height:500px;
    width:200px;
    float:left;
    padding:10px; 
}

#footer {
    background-color:blue;
   
    clear:both;
    text-align:center;
    padding:5px; 
}
 input[type=button]{ background: white; 
}
.auto-style1 {
	color: #FAEDED;
}
.auto-style3 {
	text-align: center;
}
</style></head>

<body>
<form action="" method="post">
<div id="header">
<h1>Registeration</h1>
</div>

<div id="nav">
<IMG SRC="login2.png" ALT="about us" WIDTH=300 HEIGHT=395>
</div>

<center>





<div class="input-group">

</div>

<div class="auto-style3">

	<h3>

<label>Username:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </label>
&nbsp;<input type="text" name="username" size="20" required >

<br>

<br>

	</h3>

</div>

<div class="auto-style3">

	<h3>&nbsp;
	<lable1>
	<lable1>Email&nbsp;:&nbsp;</lable1>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </lable1>
&nbsp;<input type="text" name="email" size="20" required>

<br><br></h3>
</div>

	<div class="auto-style3">

		<h3>

	<label>Password&nbsp;&nbsp; :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
	</label>&nbsp;<input id="password" name="password" type="password" pattern="^\S{6,}$" onChange="this.setCustomValidity(this.validity.patternMismatch ? 'Must have at least 6 characters' : '');
if(this.checkValidity()) form.password_2.pattern = this.value;" placeholder="Password" required><br><br>&nbsp;</h3>
</div>
	<div class="auto-style3">
		<h3>
		<label> Confirm Password :</label>
		<input id="password_two" name="confirmpass" type="password" pattern="^\S{6,}$" onChange="this.setCustomValidity(this.validity.patternMismatch ?
 'Please enter the same Password as above' : '');" placeholder="Verify Password" required><br>
		</h3>
		<h3>
		<br>
		<center>
		</center>
  <center><h3>
  <input type="submit" value="Register" name="submit"/>
  Already a member? <a href="member11.php">Sign in </a></h3>
</center><br>

<div id="footer" class="auto-style1">

<font size="4"font face="andalus">

</form>
</body>
</html>