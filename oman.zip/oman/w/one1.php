<html>
<body>
<form action="one.php" method="post">
source:
<input type ="text" name="FN" id="fullname" placeholder="firstname">
<br>
destination:
<input type ="text" name="I" id="fullname" placeholder="firstname">
<br>
<input type="submit" value="ok" >
</form>
</body>
</html>