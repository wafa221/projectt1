
<html>
<body>
<?php
$dbconnect=mysqli_connect("localhost", "root","","1234");
if(mysqli_connect_errno($dbconnect)){
	echo "failed to connect";
}
  else (echo "connection successful");}
  
  
  
?>
</body>
</html>


