<html><head>
<style type="text/css">
#header {
background-color:blue;
    
    color:white;
    text-align:center;
    padding:5px;
}
#nav {
    line-height:30px;
   
    height:500px;
    width:200px;
    float:left;
    padding:10px; 
}

#footer {
    background-color:blue;
   
    clear:both;
    text-align:center;
    padding:5px; 
}
 input[type=button]{ background: white; 
}
.auto-style1 {
	color: #FAEDED;
}
.auto-style3 {
	background-color: #92148B;
}
.auto-style4 {
	text-align: center;
}
</style></head>

<body>
<form action="" method="post">
<div class="auto-style4">
<div id="header">
<h1>Login&nbsp;</h1>
</div>
<center>
  
  <div class="input-group">
	<h2>
<labe><br><br>User Name </labe>
	<br><br>
<input type="text" name="username" size="50" required style="width: 367px; height: 36px"><br><br>
	<labe>Password</labe><br>&nbsp;<br>

	</h2>

</div>
<input type="text" name="password" size="50" required style="width: 373px; height: 33px"><br>
<br><br><a href="s5.html"><img src="forgot-password.gif" width="359" height="124" ></a><br><br><br>
	<input class="auto-style3" name="submit" type="submit" value="Login"><button type="submit" name="Forget" class="btn" Onclick=<a href="s5.html">Forget Password</button>
	<br>
</center>

	<br>
	<center></center><br></div>

<div id="footer" class="auto-style1">

<font size="4"font face="andalus">


</font>
</div>
<?php
   if(isset($_POST['submit'])) 
   {
   error_reporting(0);
        $username = $_POST['username'];
        $password = $_POST['password'];
		$link=mysql_connect('localhost','root','12345')or die(mysql_error());
		$db=mysql_select_db('pt');
        $sql = "SELECT * FROM registration WHERE username ='".$username."' AND password='".$password."' LIMIT 1";
        $result=mysql_query($sql);
        if(mysql_num_rows($result) == 1)
		{
           echo "Welcome";
			header('location:table.html');
        } 
		else 
		{
		$message1 = "Enter User Name and Password";
		echo "<script type='text/javascript'>alert('$message1');</script>";
             
        }
    } 
	?>
</form>

</body>
</html>