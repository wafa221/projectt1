<html>
<body>
<form action="one.php" method="post">
Frome:
<input type ="text" name="FN" id="fullname" placeholder="firstname">
<br>
To:
<input type ="text" name="I" id="fullname" placeholder="firstname">
<br>
<input type="submit" value="ok" >
</form>
</body>
</html>