<?php

<?php
	$a1= $_POST["FN"]; 
	$a2= $_POST["FNN"];

echo "source is :",  $a1; 
echo "<br>destination is :",  $a2;
echo "<br>";

   $dh =   'localhost';
    $du =   'root'; 
    $dp  =   '1234'; 
    $dbn =   'booking_db';
    $co  =   new mysqli( $dh, $du, $dp, $dbn );
echo ( $co ? 'database open' : 'database closed').'<br />';

$sql= "INSERT INTO login(UN,PW) VALUES('$a1','$a2')";

$result = mysqli_query($co,$sql);

 echo ( $result  ? 'Booking successful' ).'<br />';
?>

